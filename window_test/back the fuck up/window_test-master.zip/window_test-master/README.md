window_test
===========

quarkz

It's just a noobish try-out of Visual C++ (on example of Windows Forms Application).
In this project I tried out to re-write one simple Flash game in VC++.
This project has no useful purpose. It is just my college project.

The game is originally written in ActionScript using Macromedia Flash 8 by Manuel Fallmann.
http://mindistortion.tv/games/quarkz
